package com.listingproduct.stoplisting;

public class ItemType {

	public static final int ITEM_PUBLISHED = 1;
	public static final int ITEM_UNPUBLISHED = 2;
	public static final int ITEM_REJECTED = 3;
}

