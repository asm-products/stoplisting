package com.listingproduct.stoplisting;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;

}
