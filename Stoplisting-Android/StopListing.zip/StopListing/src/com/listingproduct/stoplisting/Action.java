package com.listingproduct.stoplisting;

public class Action {

	public static final String ACTION_PICK = "stoplisitng.ACTION_PICK";
	public static final String ACTION_MULTIPLE_PICK = "stoplisitng.ACTION_MULTIPLE_PICK";
	public static final String ACTION_LIVEFINDER_DETAILS = "stoplisitng.ACTION_LIVEFINDER_DETAILS";
}

