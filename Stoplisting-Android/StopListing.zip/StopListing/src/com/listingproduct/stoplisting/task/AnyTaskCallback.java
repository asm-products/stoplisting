package com.listingproduct.stoplisting.task;

public interface AnyTaskCallback {
	public void onResult(boolean success, String result);
}
