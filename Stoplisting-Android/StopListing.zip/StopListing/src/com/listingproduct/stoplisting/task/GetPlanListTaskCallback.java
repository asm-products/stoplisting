package com.listingproduct.stoplisting.task;

public interface GetPlanListTaskCallback {
	public void onResult(boolean result, String errorMsg);
}
